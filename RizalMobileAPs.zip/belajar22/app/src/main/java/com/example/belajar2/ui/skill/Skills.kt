package com.example.belajar2.ui.skill

data class Skills (val name: String, val description: String)